$(document).ready(function() {

$("#Kenya").hide();  
        $("#Namibia").hide();
        $("#Brasil").hide(); 

$("#canadaswitch").click(function() {
    $(this).toggleClass("switchino");
        $("#Canada").show();
        $("#Kenya").hide();  
        $("#Namibia").hide();
        $("#Brasil").hide(); 
    });

$("#kenyaswitch").click(function() {
    $(this).toggleClass("switchino");
        $("#Canada").hide();
        $("#Kenya").show();  
        $("#Namibia").hide();
        $("#Brasil").hide(); 
    });

$("#brazilswitch").click(function() {
    $(this).toggleClass("switchino");
        $("#Canada").hide();
        $("#Kenya").hide();  
        $("#Namibia").hide();
        $("#Brasil").show(); 
    });

$("#namibiaswitch").click(function() {
    $(this).toggleClass("switchino");
        $("#Canada").hide();
        $("#Kenya").hide();  
        $("#Namibia").show();
        $("#Brasil").hide(); 
    });


$("#Sfondo").mouseenter(function() {
    $(this).toggleClass("inside_1");
    $("#ba1").hide();
    $("#bb1").hide();
    $("#bc1").hide();
    $("#bd1").hide();
    $("#be1").hide();
    $("#bf1").hide();
    $("#bg1").hide();
    $("#bh1").hide();
    $("#bi1").hide();
    $("#bj1").hide();
    $("#bk1").hide();
    $("#bl1").hide();
    $("#bm1").hide();
    $("#bn1").hide();
    $("#bo1").hide();
    $("#bp1").hide();
    $("#bq1").hide();
    $("#br1").hide();
    $("#bs1").hide();
    $("#bt1").hide();
    $("#da1").hide();
    $("#db1").hide();
    $("#dc1").hide();
    $("#de1").hide();
    $("#df1").hide(); 
    $("#economy1").hide();
    $("#politics1").hide();
    });


$("#economy1").hide();   
$("#economylabel1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#economy1").show(); 
        });

$("#economylabel1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#economy1").hide(); 
        });

$("#politics1").hide();   
$("#politicslabel1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#politics1").show(); 
        });

$("#politicslabel1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#politics1").hide(); 
        });



$("#ba1").hide();   
$("#aa1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#ba1").show(); 
        });

$("#ba1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#ba1").hide(); 
        });


$("#bb1").hide();   
$("#ab1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bb1").show(); 
        });

$("#bb1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bb1").hide(); 
        });


$("#bc1").hide();   
$("#ac1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bc1").show(); 
        });

$("#bc1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bc1").hide(); 
        });


$("#bd1").hide();   
$("#ad1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bd1").show(); 
        });

$("#bd1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bd1").hide(); 
        });
    
$("#be1").hide();   
$("#ae1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#be1").show(); 
        });

$("#be1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#be1").hide(); 
        });


$("#bf1").hide();   
$("#af1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bf1").show(); 
        });

$("#bf1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bf1").hide(); 
        });


$("#bg1").hide();   
$("#ag1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bg1").show(); 
        });

$("#bg1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bg1").hide(); 
        });

$("#bh1").hide();   
$("#ah1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bh1").show(); 
        });

$("#bh1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bh1").hide(); 
        });

$("#bi1").hide();   
$("#ai1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bi1").show(); 
        });

$("#bi1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bi1").hide(); 
        });


$("#bj1").hide();   
$("#aj1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bj1").show(); 
        });

$("#bj1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bj1").hide(); 
        });    
     
    
$("#bk1").hide();   
$("#ak1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bk1").show(); 
        });

$("#bk1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bk1").hide(); 
        });    
    
    
$("#bl1").hide();   
$("#al1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bl1").show(); 
        });

$("#bl1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bl1").hide(); 
        });   
    
    
$("#bm1").hide();   
$("#am1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bm1").show(); 
        });

$("#bm1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bm1").hide(); 
        });  
    
$("#bn1").hide();   
$("#an1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bn1").show(); 
        });

$("#bn1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bn1").hide(); 
        });
    
$("#bo1").hide();   
$("#ao1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bo1").show(); 
        });

$("#bo1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bo1").hide(); 
        });

$("#bp1").hide();   
$("#ap1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bp1").show(); 
        });

$("#bp1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bp1").hide(); 
        });

$("#bq1").hide();   
$("#aq1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bq1").show(); 
        });

$("#bq1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bq1").hide(); 
        });

$("#br1").hide();   
$("#ar1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#br1").show(); 
        });

$("#br1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#br1").hide(); 
        });


$("#bs1").hide();   
$("#as1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bs1").show(); 
        });

$("#bs1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bs1").hide(); 
        });

$("#bt1").hide();   
$("#at1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#bt1").show(); 
        });

$("#bt1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#bt1").hide(); 
        });


$("#da1").hide();   
$("#ca1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#da1").show(); 
        });

$("#da1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#da1").hide(); 
        });


$("#db1").hide();   
$("#cb1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#db1").show(); 
        });

$("#db1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#db1").hide(); 
        });


$("#dc1").hide();   
$("#cc1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#dc1").show(); 
        });

$("#dc1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#dc1").hide(); 
        });



$("#dd1").hide();   
$("#cd1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#dd1").show(); 
        });

$("#dd1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#dd1").hide(); 
        });

    $("#de1").hide();   
$("#ce1").mouseenter(function() {
    $(this).toggleClass("inside_1");
        $("#de1").show(); 
        });

$("#de1").mouseleave(function() {
    $(this).toggleClass("outside_1");
        $("#de1").hide(); 
        });





$("#Sfondo").mouseenter(function() {
    $(this).toggleClass("inside_1");
    $("#ba2").hide();
    $("#bb2").hide();
    $("#bc2").hide();
    $("#bd2").hide();
    $("#be2").hide();
    $("#bf2").hide();
    $("#bg2").hide();
    $("#bh2").hide();
    $("#bi2").hide();
    $("#bj2").hide();
    $("#bk2").hide();
    $("#bl2").hide();
    $("#bm2").hide();
    $("#bn2").hide();
    $("#bo2").hide();
    $("#bp2").hide();
    $("#bq2").hide();
    $("#br2").hide();
    $("#bs2").hide();
    $("#bt2").hide();
    $("#da2").hide();
    $("#db2").hide();
    $("#dc2").hide();
    $("#de2").hide();
    $("#df2").hide(); 
    $("#economy2").hide();
    $("#politics2").hide();
    });


$("#economy2").hide();   
$("#economylabel2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#economy2").show(); 
        });

$("#economylabel2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#economy2").hide(); 
        });

$("#politics2").hide();   
$("#politicslabel2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#politics2").show(); 
        });

$("#politicslabel2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#politics2").hide(); 
        });



$("#ba2").hide();   
$("#aa2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#ba2").show(); 
        });

$("#ba2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#ba2").hide(); 
        });


$("#bb2").hide();   
$("#ab2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bb2").show(); 
        });

$("#bb2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bb2").hide(); 
        });


$("#bc2").hide();   
$("#ac2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bc2").show(); 
        });

$("#bc2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bc2").hide(); 
        });


$("#bd2").hide();   
$("#ad2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bd2").show(); 
        });

$("#bd2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bd2").hide(); 
        });
    
$("#be2").hide();   
$("#ae2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#be2").show(); 
        });

$("#be2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#be2").hide(); 
        });


$("#bf2").hide();   
$("#af2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bf2").show(); 
        });

$("#bf2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bf2").hide(); 
        });


$("#bg2").hide();   
$("#ag2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bg2").show(); 
        });

$("#bg2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bg2").hide(); 
        });

$("#bh2").hide();   
$("#ah2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bh2").show(); 
        });

$("#bh2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bh2").hide(); 
        });

$("#bi2").hide();   
$("#ai2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bi2").show(); 
        });

$("#bi2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bi2").hide(); 
        });


$("#bj2").hide();   
$("#aj2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bj2").show(); 
        });

$("#bj2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bj2").hide(); 
        });    
     
    
$("#bk2").hide();   
$("#ak2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bk2").show(); 
        });

$("#bk2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bk2").hide(); 
        });    
    
    
$("#bl2").hide();   
$("#al2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bl2").show(); 
        });

$("#bl2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bl2").hide(); 
        });   
    
    
$("#bm2").hide();   
$("#am2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bm2").show(); 
        });

$("#bm2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bm2").hide(); 
        });  
    
$("#bn2").hide();   
$("#an2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bn2").show(); 
        });

$("#bn2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bn2").hide(); 
        });
    
$("#bo2").hide();   
$("#ao2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bo2").show(); 
        });

$("#bo2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bo2").hide(); 
        });

$("#bp2").hide();   
$("#ap2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bp2").show(); 
        });

$("#bp2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bp2").hide(); 
        });

$("#bq2").hide();   
$("#aq2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bq2").show(); 
        });

$("#bq2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bq2").hide(); 
        });

$("#br2").hide();   
$("#ar2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#br2").show(); 
        });

$("#br2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#br2").hide(); 
        });


$("#bs2").hide();   
$("#as2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bs2").show(); 
        });

$("#bs2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bs2").hide(); 
        });

$("#bt2").hide();   
$("#at2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#bt2").show(); 
        });

$("#bt2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#bt2").hide(); 
        });


$("#da2").hide();   
$("#ca2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#da2").show(); 
        });

$("#da2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#da2").hide(); 
        });


$("#db2").hide();   
$("#cb2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#db2").show(); 
        });

$("#db2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#db2").hide(); 
        });


$("#dc2").hide();   
$("#cc2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#dc2").show(); 
        });

$("#dc2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#dc2").hide(); 
        });



$("#dd2").hide();   
$("#cd2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#dd2").show(); 
        });

$("#dd2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#dd2").hide(); 
        });

    $("#de2").hide();   
$("#ce2").mouseenter(function() {
    $(this).toggleClass("inside_2");
        $("#de2").show(); 
        });

$("#de2").mouseleave(function() {
    $(this).toggleClass("outside_2");
        $("#de2").hide(); 
        });



$("#Sfondo").mouseenter(function() {
    $(this).toggleClass("inside_3");
    $("#ba3").hide();
    $("#bb3").hide();
    $("#bc3").hide();
    $("#bd3").hide();
    $("#be3").hide();
    $("#bf3").hide();
    $("#bg3").hide();
    $("#bh3").hide();
    $("#bi3").hide();
    $("#bj3").hide();
    $("#bk3").hide();
    $("#bl3").hide();
    $("#bm3").hide();
    $("#bn3").hide();
    $("#bo3").hide();
    $("#bp3").hide();
    $("#bq3").hide();
    $("#br3").hide();
    $("#bs3").hide();
    $("#bt3").hide();
    $("#da3").hide();
    $("#db3").hide();
    $("#dc3").hide();
    $("#de3").hide();
    $("#df3").hide(); 
    $("#economy3").hide();
    $("#politics3").hide();
    });


$("#economy3").hide();   
$("#economylabel3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#economy3").show(); 
        });

$("#economylabel3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#economy3").hide(); 
        });

$("#politics3").hide();   
$("#politicslabel3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#politics3").show(); 
        });

$("#politicslabel3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#politics3").hide(); 
        });



$("#ba3").hide();   
$("#aa3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#ba3").show(); 
        });

$("#ba3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#ba3").hide(); 
        });


$("#bb3").hide();   
$("#ab3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bb3").show(); 
        });

$("#bb3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bb3").hide(); 
        });


$("#bc3").hide();   
$("#ac3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bc3").show(); 
        });

$("#bc3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bc3").hide(); 
        });


$("#bd3").hide();   
$("#ad3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bd3").show(); 
        });

$("#bd3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bd3").hide(); 
        });
    
$("#be3").hide();   
$("#ae3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#be3").show(); 
        });

$("#be3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#be3").hide(); 
        });


$("#bf3").hide();   
$("#af3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bf3").show(); 
        });

$("#bf3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bf3").hide(); 
        });


$("#bg3").hide();   
$("#ag3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bg3").show(); 
        });

$("#bg3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bg3").hide(); 
        });

$("#bh3").hide();   
$("#ah3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bh3").show(); 
        });

$("#bh3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bh3").hide(); 
        });

$("#bi3").hide();   
$("#ai3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bi3").show(); 
        });

$("#bi3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bi3").hide(); 
        });


$("#bj3").hide();   
$("#aj3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bj3").show(); 
        });

$("#bj3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bj3").hide(); 
        });    
     
    
$("#bk3").hide();   
$("#ak3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bk3").show(); 
        });

$("#bk3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bk3").hide(); 
        });    
    
    
$("#bl3").hide();   
$("#al3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bl3").show(); 
        });

$("#bl3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bl3").hide(); 
        });   
    
    
$("#bm3").hide();   
$("#am3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bm3").show(); 
        });

$("#bm3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bm3").hide(); 
        });  
    
$("#bn3").hide();   
$("#an3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bn3").show(); 
        });

$("#bn3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bn3").hide(); 
        });
    
$("#bo3").hide();   
$("#ao3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bo3").show(); 
        });

$("#bo3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bo3").hide(); 
        });

$("#bp3").hide();   
$("#ap3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bp3").show(); 
        });

$("#bp3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bp3").hide(); 
        });

$("#bq3").hide();   
$("#aq3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bq3").show(); 
        });

$("#bq3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bq3").hide(); 
        });

$("#br3").hide();   
$("#ar3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#br3").show(); 
        });

$("#br3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#br3").hide(); 
        });


$("#bs3").hide();   
$("#as3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bs3").show(); 
        });

$("#bs3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bs3").hide(); 
        });

$("#bt3").hide();   
$("#at3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#bt3").show(); 
        });

$("#bt3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#bt3").hide(); 
        });


$("#da3").hide();   
$("#ca3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#da3").show(); 
        });

$("#da3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#da3").hide(); 
        });


$("#db3").hide();   
$("#cb3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#db3").show(); 
        });

$("#db3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#db3").hide(); 
        });


$("#dc3").hide();   
$("#cc3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#dc3").show(); 
        });

$("#dc3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#dc3").hide(); 
        });



$("#dd3").hide();   
$("#cd3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#dd3").show(); 
        });

$("#dd3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#dd3").hide(); 
        });

    $("#de3").hide();   
$("#ce3").mouseenter(function() {
    $(this).toggleClass("inside_3");
        $("#de3").show(); 
        });

$("#de3").mouseleave(function() {
    $(this).toggleClass("outside_3");
        $("#de3").hide(); 
        });



$("#Sfondo").mouseenter(function() {
    $(this).toggleClass("inside_4");
    $("#ba4").hide();
    $("#bb4").hide();
    $("#bc4").hide();
    $("#bd4").hide();
    $("#be4").hide();
    $("#bf4").hide();
    $("#bg4").hide();
    $("#bh4").hide();
    $("#bi4").hide();
    $("#bj4").hide();
    $("#bk4").hide();
    $("#bl4").hide();
    $("#bm4").hide();
    $("#bn4").hide();
    $("#bo4").hide();
    $("#bp4").hide();
    $("#bq4").hide();
    $("#br4").hide();
    $("#bs4").hide();
    $("#bt4").hide();
    $("#da4").hide();
    $("#db4").hide();
    $("#dc4").hide();
    $("#de4").hide();
    $("#df4").hide(); 
    $("#economy4").hide();
    $("#politics4").hide();
    });


$("#economy4").hide();   
$("#economylabel4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#economy4").show(); 
        });

$("#economylabel4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#economy4").hide(); 
        });

$("#politics4").hide();   
$("#politicslabel4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#politics4").show(); 
        });

$("#politicslabel4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#politics4").hide(); 
        });



$("#ba4").hide();   
$("#aa4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#ba4").show(); 
        });

$("#ba4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#ba4").hide(); 
        });


$("#bb4").hide();   
$("#ab4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bb4").show(); 
        });

$("#bb4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bb4").hide(); 
        });


$("#bc4").hide();   
$("#ac4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bc4").show(); 
        });

$("#bc4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bc4").hide(); 
        });


$("#bd4").hide();   
$("#ad4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bd4").show(); 
        });

$("#bd4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bd4").hide(); 
        });
    
$("#be4").hide();   
$("#ae4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#be4").show(); 
        });

$("#be4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#be4").hide(); 
        });


$("#bf4").hide();   
$("#af4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bf4").show(); 
        });

$("#bf4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bf4").hide(); 
        });


$("#bg4").hide();   
$("#ag4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bg4").show(); 
        });

$("#bg4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bg4").hide(); 
        });

$("#bh4").hide();   
$("#ah4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bh4").show(); 
        });

$("#bh4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bh4").hide(); 
        });

$("#bi4").hide();   
$("#ai4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bi4").show(); 
        });

$("#bi4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bi4").hide(); 
        });


$("#bj4").hide();   
$("#aj4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bj4").show(); 
        });

$("#bj4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bj4").hide(); 
        });    
     
    
$("#bk4").hide();   
$("#ak4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bk4").show(); 
        });

$("#bk4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bk4").hide(); 
        });    
    
    
$("#bl4").hide();   
$("#al4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bl4").show(); 
        });

$("#bl4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bl4").hide(); 
        });   
    
    
$("#bm4").hide();   
$("#am4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bm4").show(); 
        });

$("#bm4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bm4").hide(); 
        });  
    
$("#bn4").hide();   
$("#an4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bn4").show(); 
        });

$("#bn4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bn4").hide(); 
        });
    
$("#bo4").hide();   
$("#ao4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bo4").show(); 
        });

$("#bo4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bo4").hide(); 
        });

$("#bp4").hide();   
$("#ap4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bp4").show(); 
        });

$("#bp4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bp4").hide(); 
        });

$("#bq4").hide();   
$("#aq4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bq4").show(); 
        });

$("#bq4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bq4").hide(); 
        });

$("#br4").hide();   
$("#ar4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#br4").show(); 
        });

$("#br4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#br4").hide(); 
        });


$("#bs4").hide();   
$("#as4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bs4").show(); 
        });

$("#bs4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bs4").hide(); 
        });

$("#bt4").hide();   
$("#at4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#bt4").show(); 
        });

$("#bt4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#bt4").hide(); 
        });


$("#da4").hide();   
$("#ca4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#da4").show(); 
        });

$("#da4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#da4").hide(); 
        });


$("#db4").hide();   
$("#cb4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#db4").show(); 
        });

$("#db4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#db4").hide(); 
        });


$("#dc4").hide();   
$("#cc4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#dc4").show(); 
        });

$("#dc4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#dc4").hide(); 
        });



$("#dd4").hide();   
$("#cd4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#dd4").show(); 
        });

$("#dd4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#dd4").hide(); 
        });

    $("#de4").hide();   
$("#ce4").mouseenter(function() {
    $(this).toggleClass("inside_4");
        $("#de4").show(); 
        });

$("#de4").mouseleave(function() {
    $(this).toggleClass("outside_4");
        $("#de4").hide(); 
        });



});
        
